using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using Microsoft.AspNet.OData.Extensions;
using Microsoft.AspNet.OData.Builder;
using Microsoft.OData.Edm;



namespace AdventureWorksDapper
{
    /*public class ConnectionStringList
    {
        public string AdventureWorks { get; set; }
    }*/
    public class Startup
    {
        
        private static IEdmModel GetEdmModel()  //added by sjs
        {
            ODataConventionModelBuilder builder = new ODataConventionModelBuilder();
            builder.EntitySet<Models.Person>("People");
            builder.EntitySet<Models.PersonPhone>("PersonPhones");
            return builder.GetEdmModel();
        }
        
        
        public void ConfigureServices(IServiceCollection services)
        {

            //string connection_string = services.Configure<ConnectionStringList>(Configuration.GetConnectionString("AdventureWorks").ToString());

            //services.AddControllers();
            services.AddControllers(options =>  //added by sjs
            {
                options.EnableEndpointRouting = false;
            }).AddNewtonsoftJson();   //was required to get $select working
            //.AddJsonOptions(opt =>
            
           
            services.AddOData();
           

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "AdventureWorksDapper", Version = "v1" });
            });
           
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "AdventureWorksDapper v1"));
            }

            app.UseMvc(routeBuilder =>
            {
                routeBuilder.EnableDependencyInjection();
                routeBuilder.Expand().Select().OrderBy().Filter().MaxTop(10).Count();          
                routeBuilder.MapODataServiceRoute("odata/dapper","odata/dapper", GetEdmModel()); //added 7/15/21

            });
            /*app.UseRouting();
           

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            }); */
        }
    }
}
