﻿using System.Threading.Tasks;
using System.Data.SqlClient;
using Dapper;
using AdventureWorksDapper.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNet.OData;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
//using System.Configuration;

namespace AdventureWorksDapper.Controllers
{
    [Microsoft.AspNetCore.Mvc.ApiController]
    [Route("odata/dapper")]
    //public class DapperController : Controller
    public class DapperController : ControllerBase
    {
        private IConfiguration Configuration;
        public DapperController(IConfiguration _configuration)
        {
            Configuration = _configuration;
        }

        //private const string CONNECTION_STRING = "Server=mxl9164nhh;Database=Adventureworks;Trusted_Connection=True";

        
        [Route("People")]
        [HttpGet]
        //[EnableQuery(PageSize=10, AllowedQueryOptions = Microsoft.AspNet.OData.Query.AllowedQueryOptions.All)]
        [EnableQuery()]
        //public async Task<ActionResult<IEnumerable<Person>> GetPeople()
        public  async Task<IActionResult> Person()
        {
            string connection_string = this.Configuration.GetConnectionString("AdventureWorks");
            var sql = @"select
                    [BusinessEntityID],
                    [Title],
                    [FirstName],
                    [MiddleName],
                    [LastName]
                   from [Person].[Person]
                   where firstname = @firstname";
            using (var connection = new SqlConnection(connection_string))
            {
                var people = await connection.QueryAsync<Person>(sql, new { firstName = "Ken" });
                return Ok(people);


            }
        } 

        [Route("PersonPhone")]
        [HttpGet]
        [EnableQuery()]
        public async Task<IActionResult> PersonPhone()
        {
            string connection_string = this.Configuration.GetConnectionString("AdventureWorks");
            var sql = @"select top 100
                    [BusinessEntityID],
                    [PhoneNumber],
                    [PhoneNumberTypeID],
                    [ModifiedDate]
                   from [Person].[PersonPhone]
                   Where PhoneNumberTypeId= @phonenumbertypeid
                   order by modifieddate"; 
                   
            using (var connection = new SqlConnection(connection_string))
            {         
                var PersonPhones = await connection.QueryAsync<PersonPhone>(sql, new { phonenumbertypeid = 1 });
                return Ok(PersonPhones);
            }
        }
    }
}
