﻿//using Dapper.Contrib.Extensions;
using System.ComponentModel.DataAnnotations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;


namespace AdventureWorksDapper.Models
{
    public class PersonPhone
    {
       [Required]
       [Key]
        public int BusinessEntityID { get; set; }
        [Required]
        [MaxLength(25)]
        public string PhoneNumber { get; set; }
        [Required]
        public string PhoneNumberTypeId { get; set; }
        [Required]
        public DateTime ModifiedDate { get; set; }

        public virtual ICollection <PersonPhone>PersonPhones { get; set; }
        
    }
}
