﻿
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace AdventureWorksDapper.Models
{
    //[Table("Person")]

    public class Person
    {

        [Required]
        [System.ComponentModel.DataAnnotations.Key]
        public int BusinessEntityID { get; set; }
        [MaxLength(8)]
        public string Title { get; set; }
        [Required]
        [MaxLength(50)]
        public string FirstName { get; set; }
        [MaxLength(50)]
        public string MiddleName { get; set; }
        [MaxLength(50)]
        [Required]
        public string LastName { get; set; }
        
        public virtual ICollection<Person> People { get; set; }
        
    }
            
    

        
}
